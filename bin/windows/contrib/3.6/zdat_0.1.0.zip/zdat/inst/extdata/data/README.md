## Hunter valley species

Original reference:

Wintle, B., Elith, J., & Potts, J. 2005: [Fauna habitat modelling and mapping: A review and case study in the Lower Hunter Central Coast region of NSW](http://onlinelibrary.wiley.com/doi/10.1111/j.1442-9993.2005.01514.x/full). Austral Ecology. 30:7. pp. 719-738.

species1 = [Koala](http://en.wikipedia.org/wiki/Koala) ( *Phascolarctos cinereus* )  
species2 = [Masked owl](http://en.wikipedia.org/wiki/Australian_Masked_Owl) ( *Tyto novaehollandiae* )  
species3 = [Powerful owl](http://en.wikipedia.org/wiki/Powerful_Owl) ( *Ninox strenua* )  
species4 = [Tiger quoll](http://en.wikipedia.org/wiki/Tiger_quoll) ( *Dasyurus maculatus* )  
species5 = [Sooty owl](http://en.wikipedia.org/wiki/Greater_Sooty_Owl) ( *Tyto tenebricosa)* )  
species6 = [Squirrel glider](http://en.wikipedia.org/wiki/Squirrel_glider) ( *Petaurus norfolcensis* )  
species7 = [Yellow-bellied glider](http://en.wikipedia.org/wiki/Yellow-bellied_glider) ( *Petaurus australis* )  
