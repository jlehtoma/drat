library(devtools)
library(drat)

tmp <- tempdir()
pkg_path <- devtools::build(path = tmp)
chk_results <- devtools::check_built(path = pkg_path, cran = TRUE, check_dir = tmp)
drat::insertPackage(pkg_path, commit = TRUE)
