#!/bin/sh

CURRENT_TAR=zdat_0.1.0.tar.gz

#/usr/bin/R CMD BATCH document.R
#/usr/bin/R CMD build ../../ --no-build-vignettes
/usr/bin/R CMD build ../../
/usr/bin/R CMD check --as-cran $CURRENT_TAR
#/usr/bin/R CMD INSTALL $CURRENT_TAR
#/usr/bin/R CMD BATCH document.R
